(function () {
  // Descobre automaticamente para onde chamar a API:     
  // - se estiver em localhost, usa 127.0.0.1:8000
  // - se abrir no celular (ex.: http://192.168.x.x:5500), usa esse host:8000
  const host = location.hostname;
  const proto = (location.protocol === "https:") ? "https" : "http";
  const API = (host === "localhost" || host === "127.0.0.1")
    ? "http://127.0.0.1:8000"
    : `${proto}://${host}:8000`;

  const urlEl = document.getElementById("url");
  const btn = document.getElementById("checkBtn");
  const res = document.getElementById("result");
  const badge = document.getElementById("decision");
  const msg = document.getElementById("message");
  const err = document.getElementById("error");
  const hint = document.getElementById("hint");

  const mapDecision = (d) => {
    switch (d) {
      case "clean": return { text: "SEGURO", cls: "d-clean", note: "Este link parece seguro." };
      case "malicious": return { text: "PERIGOSO", cls: "d-malicious", note: "Não recomendamos abrir este link." };
      case "suspicious": return { text: "SUSPEITO", cls: "d-suspicious", note: "Cuidado. Pode ser arriscado." };
      default: return { text: "DESCONHECIDO", cls: "d-unknown", note: "Não foi possível confirmar com certeza." };
    }
  };

  function setBusy(b) {
    btn.disabled = b || !/^https?:\/\//i.test((urlEl.value || "").trim());
    urlEl.disabled = !!b;
  }

  urlEl.addEventListener("input", () => setBusy(false));
  urlEl.addEventListener("keydown", (e) => { if (e.key === "Enter" && !btn.disabled) doCheck(); });
  btn.addEventListener("click", doCheck);

  async function doCheck() {
    const url = (urlEl.value || "").trim();
    err.style.display = "none";

    if (!/^https?:\/\//i.test(url)) {
      err.textContent = "Digite um endereço válido (começando com http:// ou https://).";
      err.style.display = "block";
      return;
    }

    setBusy(true);
    res.classList.add("visible");
    badge.className = "decision d-unknown";
    badge.textContent = "ANALISANDO…";
    msg.textContent = "Por favor, aguarde.";

    try {
      const trace = (crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now());
      const r = await fetch(`${API}/validar_link`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Request-Id": trace },
        body: JSON.stringify({ url })
      });
      const data = await r.json().catch(() => ({}));

      const m = mapDecision(data.decision || "unknown");
      badge.className = "decision " + m.cls;
      badge.textContent = m.text;
      msg.textContent = m.note;

      // logs técnicos só no console
      console.log("[resultado]", { api: API, status: r.status, trace_id: data.trace_id, took_ms: data.took_ms });
    } catch (e) {
      badge.className = "decision d-unknown";
      badge.textContent = "ERRO";
      msg.textContent = "Não foi possível verificar agora. Tente novamente.";
      console.log("[erro]", String(e));
    } finally {
      setBusy(false);
    }
  }

  // estado inicial
  setBusy(false);
})();
